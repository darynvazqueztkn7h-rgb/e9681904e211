// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("differential fuzz\n", stdout);
  return lionss_run_workload("differential-fuzz");
}
