// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("qemu aarch64\n", stdout);
  return lionss_run_workload("qemu-aarch64");
}
