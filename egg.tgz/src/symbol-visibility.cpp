// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("symbol visibility"); }
int main(){
  announce();
  return lionss_run_workload("symbol-visibility");
}
