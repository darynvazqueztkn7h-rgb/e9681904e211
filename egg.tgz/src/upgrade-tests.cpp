// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("upgrade tests\n", stdout);
  return lionss_run_workload("upgrade-tests");
}
